using CadEditor;
using System;
using System.Drawing;

public class Data 
{ 
  public GameType getGameType()        { return GameType.Generic; }
  public OffsetRec getScreensOffset()  { return new OffsetRec(0x2B60+1, 1 , 64*50);   }
  public int getScreenWidth()          { return 64; }
  public int getScreenHeight()         { return 50; }
  public int getScreenDataStride()     { return 2;} 
  public string getBlocksFilename()    { return "sega_lost_vikings_1.png"; }
  
  public bool isBigBlockEditorEnabled() { return false; }
  public bool isBlockEditorEnabled()    { return false; }
  public bool isLayoutEditorEnabled()   { return false; }
  public bool isEnemyEditorEnabled()    { return false; }
  public bool isVideoEditorEnabled()    { return false; }
}